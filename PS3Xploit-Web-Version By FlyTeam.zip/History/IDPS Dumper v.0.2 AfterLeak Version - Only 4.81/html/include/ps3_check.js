var isPlaystation = false;
var disableFeatures = false;
var ua = navigator.userAgent;
var uaStringCheck = ua.substring(ua.indexOf("5.0 (") + 5, ua.indexOf(") Apple") - 7);
var fwVersion = ua.substring(ua.indexOf("5.0 (") + 19, ua.indexOf(") Apple"));

// Compatible Firmware Versions
//var fwCompat = ["3.55", "4.81"];
var fwCompat = ["4.81"];

// If the system is not a playstation, disable features, display error
switch (uaStringCheck) {
    case "PLAYSTATION":
        isPlaystation = true;
        break;

    default:
        $("#message").append('<div class="alert alert-danger"><strong>You are not on a PlayStation System!</strong> The "Run POC" button and all other features have been disabled</div>');
        disableFeatures = true;
        isPlaystation = false;
        $(".expl_buttons").prop("disabled", true);
        $('.expl_buttons').attr('disabled', true);
        break;
}

// If the system is a playstation, ensure the version is 3.55 or 4.81!
if (isPlaystation) {
    switch (fwVersion) {
        // Compatible Firmware Version Detected
        //case "3.55": case "4.81":
        case "4.81":
            $("#message").append('<div class="alert alert-success"><strong>Congratulations!</strong> We\'ve detected your PlayStation 3 is running FW ' + fwVersion + ', which is compatible with PS3Xploit! Enjoy!</div>');
            break;

        // No Compatible Firmware Version Was Detected
        default:
            $("#message").append('<div class="alert alert-danger"><strong>Your PS3 is not on FW 4.81!</strong> Your current running FW version is ' + fwVersion + ', which is not compatible with PS3Xploit. The "Evaluate" button and all other features have been disabled</div>');
            disableFeatures = true;
            break;
    }
}