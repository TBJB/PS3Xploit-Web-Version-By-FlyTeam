// global vars
//var _log;

/*
//new global vars
//var mem = 0;
var STEP = 0x45000;
function find_str_step(str, returnOffset)
{
	if (i >= memsize) {
		dbg("Out of limits! i: 0x" + i.toString(16).toUpperCase());
		return;
	}
	var strlen = str.length;
	dbg("Pos: 0x" + i.toString(16).toUpperCase());
	var n = i;
	do {
		n = find_str_n(n, STEP, str);
		if (n > 0) {
			if(returnOffset == true) {
				dbg("0x" + n.toString(16).toUpperCase());
				return n.toString(16);
			}
			sendmsg("0x" + n.toString(16) + ": " + get_stringz(n));
			n += strlen;
		} else {
			break;
		}
	} while (n >= 0);
	i += STEP;
	return 0;
}
*/
function send_disasm(addr, size, _log_div)
{
	var temp=readMemory(document.getElementById('exploit'),addr,size+12);
	temp=temp.substr(0,temp.length-6);
	var mem=temp.substr(6,size);
	dbg("Disassembling from 0x" + addr.toString(16).toUpperCase() +
		   " to 0x" + (addr+size).toString(16).toUpperCase(), _log_div);
	//sendcmsg("disasm", addr, get_bytes_str(addr, size));
	sendcmsg("disasm", addr, bytesToHex(mem)); 
	
}

function send_read(mem, addr, size, _log_div)
{

	//var temp=readMemory(document.getElementById('exploit'),addr,size+0x100);
	//dbg("passed size = "+size+" temp: size = "+temp.length+" data = "+bytesToHex(temp), _log_div);
	//var mem=temp.substr(6,size);

	dbg("mem: size = "+mem.length+" data = "+bytesToHex(mem), _log_div);
	dbg("Reading from 0x" + addr.toString(16).toUpperCase() +
		   " to 0x" + (addr+size).toString(16).toUpperCase() +
		   " (" + size/1024 + "kB)", _log_div);
	//sendcmsg("read", addr, get_bytes_str(mem, addr, size));
	sendcmsg("read", addr, bytesToHex(mem));
	//mem=null;
}
function send_readhex(addr, size, _log_div)
{
	var temp=readMemory(document.getElementById('exploit'),addr,size+12);
	temp=temp.substr(0,temp.length-6);
	var mem=temp.substr(6,size);
	dbg("mem: "+bytesToHex(mem), _log_div);
	dbg("Reading from 0x" + addr.toString(16).toUpperCase() +
		   " to 0x" + (addr+size).toString(16).toUpperCase() +
		   " (" + (size/1024)/1024 + "MB)", _log_div);
	//sendcmsg("read", addr, get_bytes_str(mem, addr, size));
	sendcmsg("read", addr, s2hex(mem));

}
function send_dump_name(mem, addr, size, name, _log_div)
{
	//var temp=readMemory(document.getElementById('exploit'),addr,size+12);
	//temp=temp.substr(0,temp.length-6);
	//var mem=temp.substr(6,size);
	dbg("Dumping from 0x" + addr.toString(16).toUpperCase() +
		   " to 0x" + (addr+size).toString(16).toUpperCase() +
		   " (" + (size/1024)/1024 + "MB)");
	//sendcmsg("dump", addr, get_bytes_str(addr, size), name);
		sendcmsg("dump", addr, bytesToHex(mem), name);
}

function send_dump(addr, size, _log_div)
{
	var temp=readMemory(document.getElementById('exploit'),addr,size+12);
	temp=temp.substr(0,temp.length-6);
	var mem=temp.substr(6,size);
	dbg("Dumping from 0x" + addr.toString(16).toUpperCase() +
		   " to 0x" + (addr+size).toString(16).toUpperCase() +
		   " (" + (size/1024)/1024 + "MB)", _log_div);
	var filename = "0x" + hex32(addr.toString(16).toUpperCase()) + "-0x" +
					hex32((addr+size).toString(16).toUpperCase()) + ".bin";
	//sendcmsg("dump", addr, get_bytes_str(addr, size), filename);
		sendcmsg("dump", addr, bytesToHex(mem), filename);
}

//String functions

/* function get_bytes_str(mem, addr, size)
{
	var s = "";
	var end = addr+size;
	for (var i = addr; i < end; i++) {
		s = s + hex8(lb(mem,i).toString(16));
	}
	return s.toUpperCase();
}

function get_bytes(addr, size)
{
	var array = [];
	var end = addr+size;
	for (var i = addr; i < end; i++) {
		array.push(lb(i));
	}
	return array;
}

function get_stringz(addr)
{
	var str = "";
	for (var i = addr; lb(i) != 0; i++) {
		str = str + String.fromCharCode(lb(i));
	}
	return str;
}

function get_string(addr, length)
{
	var str = "";
	var end = addr+length;
	for (var i = addr; i < end; i++) {
		str = str + String.fromCharCode(lb(i));
	}
	return str;
}

function find_str_n(start_addr, size, s)
{
	var end = start_addr+size;
	var found = true;
	var len = s.length;
	for (var i = start_addr; i < end; i++) {
		found = true;
		for (var j = 0; j < len && found; j++) {
			if (lb(i+j) != asciiAt(s, j)) {
				found = false;
			}
		}
		if (found) {
			return i;
		}
	}
	return -1;
}

function find_str(start_addr, s)
{
	var found = true;
	var len = s.length;
	for (var i = start_addr; i < memsize; i++) {
		found = true;
		for (var j = 0; j < len && found; j++) {
			if (lb(i+j) != asciiAt(s, j)) {
				found = false;
			}
		}
		if (found) {
			return i;
		}
	}
	return -1;
} */

function asciiAt(str, i)
{
	return str.charCodeAt(i)&0xFF;
}

function str2ascii(str)
{
	var ascii = "";
	for (var i = 0; i < str.length; i++) {
		ascii += str.charCodeAt(i).toString(16);
	}
	return ascii;
}

//Memory functions
/* function lb(mem, addr)
{
//dbg("Byte: " + mem.charCodeAt(addr/2).toString(16)+"\r\n");
	if (addr%2 == 0) {
		return mem.charCodeAt(addr/2)>>8;
	} else {
		return mem.charCodeAt(addr/2)&0xFF;
	}
}

function lh(addr)
{
	if (addr%2 == 0) {
		return mem.charCodeAt(addr/2);
	} else {
		return (lb(addr)<<8) | lb(addr+1);
	}
}

function lw(addr)
{
	return (lh(addr)<<16) | lh(addr+2);
} */
// Convert a hex string to a byte array
function hexToBytes(hex) {
	var bytes = [];
    for (var c = 0; c < hex.length; c += 2)
    bytes.push(parseInt(hex.substr(c, 2), 16));
    return bytes;
}
function Repeat(s, n)
{
	var a = [];
	
	while(a.length < n)
	{
		a.push(s);
	}
	return a.join('');
}
function hexh2bin(hex_val)
{
	var str = "";
	var half = hex_val & 0xFFFF;
	
	// get hex
	str = half.toString(16);
	
	// pad as needed
	if (str.length < 3)
	{
		str = "%" + Repeat("0", 2 - str.length) + str;
	}
	else
	{
		str = "%u" + Repeat("0", 4 - str.length) + str;
	}
	
	return unescape(str);
}

function hexw2bin(hex_val)
{
	// 1 word = 2 halfs
	return "" + hexh2bin(hex_val) + "" + hexh2bin(hex_val >> 16);
}

/* function s2hex(str) 
{
	var ret = "";
	for (var i = 0; i < str.length; i++)
	{
		ret+=hex16((str.charCodeAt(i)).toString(16));
	}
	return ret.toUpperCase();
} */

function s2hex(str) 
{
	var str_ret = '';
	for (var i = 0; i < str.length; i++)
	{
		if(str.charCodeAt(i)==0){
			str_ret+=hex8((str.charCodeAt(i) >>> 4).toString(16));
			str_ret+=hex8((str.charCodeAt(i) & 0xF).toString(16));
		}
		else
		{
			str_ret+=(str.charCodeAt(i) >>> 4).toString(16);
			str_ret+=(str.charCodeAt(i) & 0xF).toString(16);
		}
	}
	//return str_ret.toUpperCase();
	return str_ret;
}


// Convert a byte array to a hex string
/* function bytesToHex(str) {
	var hex = [];
    for (var  i = 0; i < str.length; i++) {
		hex.push(hex16((str.charCodeAt(i)).toString(16)));
    }
    return hex.join("").toUpperCase();
} */
function bytesToHex(str) {
	var hex = [];
    for (var  i = 0; i < str.length; i++) {
		if(str.charCodeAt(i)==0){
			hex.push(hex8((str.charCodeAt(i) >>> 4).toString(16)));
			hex.push(hex8((str.charCodeAt(i) & 0xF).toString(16)));
		}
		else
		{
			hex.push((str.charCodeAt(i) >>> 4).toString(16));
			hex.push((str.charCodeAt(i) & 0xF).toString(16));
		}
    }
    //return hex.join("").toUpperCase();
	return hex.join("");
}
function hex32(s)
{
	return ('00000000' + s).substr(-8);
}
function hex16(s)
{
	return ('0000' + s).slice(-4)
}
function hex8(s)
{
	return ('00' + s).substr(-2);
}


function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

/*
    Send message to server-synchronous javascript
*/

function dbg(txt,_log)
{
	logAdd(txt,_log);
    sendmsg(txt);
}

/*
    Get a command from the server
*/
function getcmd()
{
    try {
        var cmd = "";
        handler = function(data, stat) {
			cmd = data;
		}
        $.ajax({
            type: 'GET',
            url: '/Command',
            success: handler,
            async: false
        });
    } catch(e) {
        logdbg("GetCMDError: " + e);
        return "FAIL";
    }
    return "";
}

/*
    POST text (hexencoded string) to server
*/
function sendcmsg(type, addr, txt, extra)
{
    try {
        var dat = {type: type, addr: addr, data: txt, extra: extra};
        $.ajax({
            type: 'POST',
            url: '/Data',
            data: dat,
            async: false
        });
    }catch(e){
        logdbg("SendCMsgError: " + e);
    }
}

/*
    Send message to server-synchronous javascript
*/
function sendmsg(txt)
{
    var dat = {dbg: txt};
    $.ajax({
        type: 'GET',
        url: '/Debug',
        data: dat,
        async: false
    });
}

/*
    Send debug msg to server
*/
function logdbg(txt)
{
    sendmsg(txt);
}

/*
	Print log messages
*/
function logEntry()
{
		var _loggger = document.getElementById("log");
		if (!_loggger) return 0;
		var logger = document.createElement("div");
		if (_loggger.hasChildNodes()){
			_loggger.insertBefore(logger, _loggger.firstChild);
		}else{
			_loggger.appendChild(logger);
		}
		return logger;
}
function logAdd(txt,_log)
{
	// if (!_log0){
		// _log0 = document.getElementById("log");
		// if (!_log0) return;
	// }
	// if (!_log){
		// _log = document.createElement("div");
		// if (_log0.hasChildNodes()){
			// _log0.insertBefore(_log, _log0.firstChild);
		// }else{
			// _log0.appendChild(_log);
		// }
	// }
	// var div = document.createElement("div");
	// div.innerHTML = txt;
	// _log.appendChild(div);
	
	if(!_log) return;
	var div = document.createElement("div");
	div.innerHTML = txt;
	_log.appendChild(div);
}

// prints environment info
function writeEnvInfo(__log_div)
{
	// document.write(new Date().toTimeString() + "<br/>");
	// document.write(navigator.userAgent + "<br/>");
	// document.write(navigator.appName + " (" + navigator.platform + ")<br/><br/>");
	logAdd("<h3>PS3 System Browser Info:</h3>",__log_div);
	logAdd("<br>"+navigator.userAgent + "<br>",__log_div);
	logAdd(navigator.appName + " (" + navigator.platform + ")<br>",__log_div);
	logAdd(new Date().toTimeString() + "<br>",__log_div);
}

function setCharAt(str,index,chr) 
{
	if(index > str.length-1) return str;
	return str.substr(0,index) + chr + str.substr(index+1);
}

String.prototype.replaceAt=function(index, ch) 
{
	return this.substr(0, index) + ch + this.substr(index+ch.length);
}

